from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__, template_folder='template') 

# --- Configuração do Banco de Dados ---
# Usaremos SQLite para simplificar, mas você pode mudar para PostgreSQL, MySQL, etc.
# SQLALCHEMY_DATABASE_URI: Define a URI do banco de dados.
#   Para SQLite: 'sqlite:///nome_do_seu_banco.db'
#   Para PostgreSQL: 'postgresql://user:password@host:port/database_name'
#   Para MySQL: 'mysql+mysqlconnector://user:password@host/database_name'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///meubanco.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False # Desativa o rastreamento de modificações, economiza memória

db = SQLAlchemy(app)

# --- Modelo do Banco de Dados ---
# Define a estrutura da tabela 'Usuario' no banco de dados.
class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    endereco = db.Column(db.String(100), nullable=False)
    numero = db.Column(db.String(100), nullable=False)
    estado = db.Column(db.String(2), nullable=False)
    telefone = db.Column((db.String(9)), nullable=False)   


    def __repr__(self):
        return f'<Usuario {self.nome}>'

# --- Criação do Banco de Dados ---
# Isso cria as tabelas no banco de dados, se elas não existirem.
with app.app_context():
 
    db.create_all()

# --- Rotas e Operações CRUD ---
# Rota para Listar Todos os Usuários (READ)
@app.route('/')
def index():
    usuarios = Usuario.query.all()
    return render_template('index.html', usuarios=usuarios)

# Rota para Adicionar Novo Usuário (CREATE)
@app.route('/adicionar', methods=['GET', 'POST'])
def adicionar_usuario():
    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        endereco = request.form['endereco']
        numero = request.form['numero']
        estado = request.form['estado']
        telefone = request.form['telefone']

        novo_usuario = Usuario(
            nome=nome,
            email=email,
            endereco=endereco,
            numero=numero,
            estado=estado,
            telefone=telefone
        )
        db.session.add(novo_usuario)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('adicionar.html')

# Rota para Editar Usuário (UPDATE)
@app.route('/editar/<int:id>', methods=['GET', 'POST'])
def editar_usuario(id):
    usuario = Usuario.query.get_or_404(id)
    if request.method == 'POST':
        usuario.nome = request.form['nome']
        usuario.email = request.form['email']
        usuario.endereco = request.form['endereco']
        usuario.numero = request.form['numero']
        usuario.estado = request.form['estado']
        usuario.telefone = request.form['telefone']
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('editar.html', usuario=usuario)

# Rota para Deletar Usuário (DELETE)
@app.route('/deletar/<int:id>')
def deletar_usuario(id):
    usuario = Usuario.query.get_or_404(id)
    db.session.delete(usuario)
    db.session.commit()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)